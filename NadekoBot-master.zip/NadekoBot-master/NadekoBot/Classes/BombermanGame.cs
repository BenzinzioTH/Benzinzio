﻿namespace NadekoBot.Classes
{
    class BombermanGame
    {
        public ulong ChannelId { get; internal set; }
        public bool Ended { get; internal set; }
    }
}
