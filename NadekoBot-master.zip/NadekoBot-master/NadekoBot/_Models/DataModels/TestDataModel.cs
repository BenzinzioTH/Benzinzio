﻿namespace NadekoBot.DataModels
{
    internal class TestDataModel : IDataModel
    {
        public long TestNumber { get; set; }
        public string TestString { get; set; }
    }
}
