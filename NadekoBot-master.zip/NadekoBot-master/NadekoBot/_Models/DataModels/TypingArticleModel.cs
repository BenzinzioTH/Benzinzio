﻿namespace NadekoBot.DataModels {
    internal class TypingArticle : IDataModel {
        public string Text { get; set; }
    }
}
