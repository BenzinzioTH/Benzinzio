namespace NadekoBot.DataModels
{
    internal class PlaylistSongInfo : IDataModel
    {
        public int PlaylistId { get; set; }
        public int SongInfoId { get; set; }
    }
}
