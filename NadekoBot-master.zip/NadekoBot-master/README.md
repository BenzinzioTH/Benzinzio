![img](https://ci.appveyor.com/api/projects/status/gmu6b3ltc80hr3k9?svg=true)
[![Discord](https://discordapp.com/api/guilds/117523346618318850/widget.png)](https://discord.gg/0ehQwTK2RBjAxzEY)
[![Documentation Status](https://readthedocs.org/projects/nadekobot/badge/?version=latest)](http://nadekobot.readthedocs.io/en/latest/?badge=latest)
# NadekoBot

## [Click here to invite Nadeko to your Discord server](https://discordapp.com/oauth2/authorize?client_id=170254782546575360&scope=bot&permissions=66186303)
## [Click here for a list of commands](http://nadekobot.readthedocs.io/en/latest/Commands%20List/)
## Instructions, FAQ, other info ---> [Documentation](http://nadekobot.readthedocs.io/en/latest)

You might want to join my discord server where i can provide help etc. https://discord.gg/0ehQwTK2RBjAxzEY
